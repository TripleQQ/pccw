package pccw.sample.login.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import lombok.extern.slf4j.Slf4j;
import pccw.sample.login.dto.request.UserDetailDto;
import pccw.sample.login.dto.request.loginRequestDto;
import pccw.sample.login.dto.response.JwtAuthenticationResponse;
import pccw.sample.login.dto.response.RegisterResponseDto;
import pccw.sample.login.service.AuthenticationService;


@RestController
@RequestMapping("/api/auth")
@Slf4j
public class LoginController {
	
	@Autowired
	private  AuthenticationService authenticationService;
	
	@PostMapping("/register")
	public ResponseEntity<RegisterResponseDto> register(@RequestBody UserDetailDto request){
		var jwt=authenticationService.register(request);
		return  ResponseEntity.ok(jwt );
	}
	
	 @PostMapping("/login")
	 public ResponseEntity<JwtAuthenticationResponse> login( @RequestBody loginRequestDto request) {
		var jwt = authenticationService.login(request);
	        return ResponseEntity.ok(jwt);
	    }

}
