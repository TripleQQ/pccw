package pccw.sample.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;
import pccw.sample.login.dto.request.UserDetailDto;
import pccw.sample.login.dto.request.loginRequestDto;
import pccw.sample.login.dto.response.JwtAuthenticationResponse;
import pccw.sample.login.service.AuthenticationService;
import pccw.sample.login.service.UserService;

@RestController
@RequestMapping("/api/user")
@Slf4j
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/update/{id}")
	public ResponseEntity<UserDetailDto> update(@PathVariable Long id,@RequestBody UserDetailDto request){
		var userDto =userService.updateUser(id, request);
		return  ResponseEntity.ok(userDto );
	}
	
	
}
