package pccw.sample.login.dto.request;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pccw.sample.login.dto.response.JwtAuthenticationResponse;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDetailDto {
	
	 private long userId;
	
	 private String username;
	 
	 private String password;
	 
	 private String email;
	 
	 private LocalDateTime updatedAt;

	 
	 
	 	 

}
