package pccw.sample.login.entity;

public enum Role {
	
	ROLE_ADMIN,
	ROLE_USER

}
