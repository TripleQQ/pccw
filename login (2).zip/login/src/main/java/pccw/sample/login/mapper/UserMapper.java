package pccw.sample.login.mapper;

import pccw.sample.login.dto.request.UserDetailDto;
import pccw.sample.login.entity.User;

public class UserMapper {
    public static UserDetailDto toUserDTO(User user) {
    	UserDetailDto dto = new UserDetailDto();
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        dto.setUserId(user.getId());
        dto.setUpdatedAt(user.getUpdatedAt());
        return dto;
    }

    public static User toUser(UserDetailDto dto) {
        User user = new User();
        user.setId(dto.getUserId());
        user.setUsername(dto.getUsername());
        user.setEmail(dto.getEmail());
        return user;
    }
}