package pccw.sample.login.service;

import pccw.sample.login.dto.request.UserDetailDto;
import pccw.sample.login.dto.request.loginRequestDto;
import pccw.sample.login.dto.response.JwtAuthenticationResponse;
import pccw.sample.login.dto.response.RegisterResponseDto;

public interface AuthenticationService {
	   public RegisterResponseDto register(UserDetailDto request);
	   public JwtAuthenticationResponse login(loginRequestDto request);
}
