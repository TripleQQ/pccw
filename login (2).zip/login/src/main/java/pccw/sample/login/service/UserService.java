package pccw.sample.login.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetailsService;

import pccw.sample.login.dto.request.UserDetailDto;
import pccw.sample.login.entity.User;

public interface UserService {
	public List<User> getAllUsers();
	
	public Optional<User> getUserById(Long id);
	
	public UserDetailsService userDetailsService();
	
	public User createUser(User user);
	
	public UserDetailDto updateUser(Long id, UserDetailDto userDetails);
	
	public void deleteUser(Long id);
	public Optional<User> findByUsername(String username);
	
	public Optional<User> findByEmail(String email);
}
