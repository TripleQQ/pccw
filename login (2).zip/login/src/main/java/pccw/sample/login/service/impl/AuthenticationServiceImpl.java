package pccw.sample.login.service.impl;

import java.sql.Date;
import java.time.LocalDateTime;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import pccw.sample.login.dto.request.UserDetailDto;
import pccw.sample.login.dto.request.loginRequestDto;
import pccw.sample.login.dto.response.JwtAuthenticationResponse;
import pccw.sample.login.dto.response.RegisterResponseDto;
import pccw.sample.login.repository.UserRepository;
import pccw.sample.login.security.jwt.JwtService;
import pccw.sample.login.service.AuthenticationService;
import pccw.sample.login.service.UserService;
import pccw.sample.login.entity.Role;
import pccw.sample.login.entity.User;
@Service
@RequiredArgsConstructor
@Slf4j
public class AuthenticationServiceImpl implements AuthenticationService {
	    
	    private final PasswordEncoder passwordEncoder;
	    
	    private final UserService userService;
	    
	    private final JwtService jwtService;
	    
	    private final AuthenticationManager authenticationManager;
	    
	    private final static String USER_NAME_DUPLICATE="User name already existed in database";
	    private final static String USER_EMAIL_DUPLICATE="User email already existed in database";

	    private final static String OUTCOME_FAIL="FAIL";
	    private final static String OUTCOME_SUCCESSFUL="SUCCESSFUL";
	    private final static String OUTCOME_SUCCESSFUL_MSG="the user account have been resgiter successful";
	    

	    public RegisterResponseDto register(UserDetailDto request) {
	    	if(userService.findByUsername(request.getUsername()).isPresent()) {
	    		return generateFailResponse(USER_NAME_DUPLICATE);
	    	}
	    	if(userService.findByEmail(request.getEmail()).isPresent()) {
	    		return generateFailResponse(USER_EMAIL_DUPLICATE);
	    	}
			var user = User.builder()//Lombok @Builder
					   .username(request.getUsername())
					   .email(request.getEmail())
					   .password(passwordEncoder.encode(request.getPassword()))
					   .role(Role.ROLE_USER)
					   .createdAt(LocalDateTime.now())
					   .build();
			log.info("Email:->{},Password->{} id->{},name->{}",user.getEmail(),user.getPassword(),user.getId(),user.getUsername());
	    	user = userService.createUser(user);
			log.info("Email:->{},Password->{} id->{},name->{}",user.getEmail(),user.getPassword(),user.getId(),user.getUsername());

			log.info("update:->{},create->{} ",user.getUpdatedAt(),user.getCreatedAt());

	    	var jwt = jwtService.generateToken(user);
	    	return RegisterResponseDto.builder().outcome(OUTCOME_SUCCESSFUL).message(OUTCOME_SUCCESSFUL_MSG).build();	    	
	    }
	    


		private RegisterResponseDto  generateFailResponse(String errorMsg) {
			return RegisterResponseDto.builder().outcome(OUTCOME_FAIL).message(errorMsg).build();
			
		}



		public JwtAuthenticationResponse login(loginRequestDto request) {
	    	authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(),request.getPassword()));
	    	var user = userService.findByUsername(request.getUsername()).orElseThrow(()->new IllegalArgumentException("Invalid User Name"));
	    	
	    	var jwt = jwtService.generateToken(user);
	    	
	    	
	    	return JwtAuthenticationResponse.builder().token(jwt).build();	    	
	    }


}
