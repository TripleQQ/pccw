package pccw.sample.login.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import pccw.sample.login.dto.request.UserDetailDto;
import pccw.sample.login.entity.User;
import pccw.sample.login.mapper.UserMapper;
import pccw.sample.login.repository.UserRepository;
import pccw.sample.login.service.UserService;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepository userRepository;
    



    public UserDetailsService userDetailsService() {
    	
    	return new UserDetailsService() {
    		@Override
    		public UserDetails loadUserByUsername(String userName) {
    			return userRepository.findByUsername(userName).orElseThrow(()->new UsernameNotFoundException("Unable to find user name: "+userName));
    		}
    	};
    }
    public User save(User user) {
    	return userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }





    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        
        userRepository.save(user);
    }
    @Transactional(readOnly = true)
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    @Transactional(readOnly = true)
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    @Transactional
	@Override
	public User createUser(User user) {
		
		return userRepository.save(user);
	}
	@Transactional
	@Override
	public UserDetailDto updateUser(Long id, UserDetailDto userDetails) {
		var user=userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
		user.setEmail(userDetails.getEmail());
		userRepository.save(user);
		log.info("Email->{},updateTime->{},createed-{}",user.getEmail(),user.getUpdatedAt(),user.getCreatedAt());
		return UserMapper.toUserDTO(user);
	}
}
